# CerebellumAstrocyteSimulation
Code and package to performe astrocyte lineage simulation
